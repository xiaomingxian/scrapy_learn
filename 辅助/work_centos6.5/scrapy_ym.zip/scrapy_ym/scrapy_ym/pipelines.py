# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import json
import time
import io
import sys
import logging

defaultencoding = 'utf-8'
if sys.getdefaultencoding() != defaultencoding:
    reload(sys)
    sys.setdefaultencoding(defaultencoding)

logger = logging.getLogger(__name__)


# 没执行一次爬虫命令就创建一个文件
class workPipleLine(object):
    # 初始化的时候只执行一次
    def __init__(self, CN_RESULT):
        self.result_root = CN_RESULT
        self.file_name = "/yu_" + (str(time.time()).replace(".", "")) + '.json'
        self.mail_file_name = "/mail_" + (str(time.time()).replace(".", "")) + '.json'
        self.yf = None
        self.mf = None

        pass

    @classmethod
    def from_crawler(cls, crawler):
        settings = crawler.settings
        if settings['CN_RESULT']:
            return cls(CN_RESULT=settings['CN_RESULT'])

    def process_item(self, item, spider):
        if spider.name == 'work':
            if item['type'] == 'cn':
                fileName = self.result_root + self.file_name
                if self.yf == None:
                    self.yf = open(fileName, 'a')
                    self.yf.write('[\n')
                    self.yf.flush()
                self.writeContext(item, self.yf)
            elif item['type'] == 'mail':
                fileName = self.result_root + self.mail_file_name
                if self.mf == None:
                    self.mf =open(fileName, 'a')
                    self.mf.write('[\n')
                    self.mf.flush()

                self.writeContext(item, self.mf)

    def writeContext(self, item, file):
        # 转成字典类型--再转成json,中文处理-->最终转成字符串
        context = json.dumps(dict(item), ensure_ascii=False).__str__() + "\n,\n"
        file.write(context)
        file.flush()
        return item

    def close_spider(self, spider):
        # 读取最后一行删除逗号
        # 文件存在才关闭
        # 域名文件
        if self.yf != None:
            self.yf.close()
            lines = []
            f = open(str(self.yf.name), 'r')
            lines = f.readlines()
            lines[len(lines) - 1] = ']'
            f = open(str(self.yf.name), 'w+')
            f.writelines(lines)
            f.flush()
            f.close()
            logger.info("=====>域名结果文件写入完成")

        # 邮箱文件
        if self.mf != None:
            self.mf.close()
            lines = []
            f = open(str(self.mf.name), 'r')
            lines = f.readlines()
            lines[len(lines) - 1] = ']'
            f = open(str(self.mf.name), 'w+')
            f.writelines(lines)
            f.flush()
            f.close()
            logger.info("=====>邮箱结果文件写入完成")
